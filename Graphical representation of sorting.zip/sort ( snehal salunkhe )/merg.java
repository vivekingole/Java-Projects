import java.awt.*;
import javax.swing.*;
import java.io.*;

class merg extends JFrame
{
  static merg o;
  int[] x = { 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 0, 0 };
  int[] y = { 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 0, 0 };
  int n; int[] item = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  int[] t = new int[13];
  int[] tm = new int[12];
  int[][] mrg = new int[11][5]; int mc = 0;
  int[][] srt = new int[11][5]; int sc = 0;
  int[][] res = new int[12][12]; int rs = 0;
  Graphics g;
  Container c;
  int t1; int f = 0; int i; int k; int j; int pass = 1;
  int ad;
  
  merg(int[]a, int n, int ad) 
	{
		setBounds(1, 1, 1300, 800);
    setVisible(true);
    setDefaultCloseOperation(1);
    item =a;
    this.n = n;
    this.ad = ad;
    setLayout(null);
    c = getContentPane();
    c.setBackground(new Color(248, 248, 248));
    g = c.getGraphics();
    g.setColor(Color.red);
    g.setFont(new Font("Arial Rounded MT Bold", 3, 20));
    copy(tm, item);
    s1(tm);
    try { Thread.sleep(1000L); } catch (Exception e1) {}
    mergsort(item, 0, n - 1);
    divide();
    concer();
  }
  
  public void divide() {
    for (int m = 0; m < n - 1; m++) {
      int i1;
      if (mrg[m][0] == 0)
      {
        for (i1 = 0; i1 <= mrg[m][1]; i1++)
        {
          rougf(i1);
          x[i1] -= 50;
        }
        
      }
      else {
        for (i1 = mrg[m][2]; i1 < n; i1++)
        {
          rougf(i1);
          x[i1] += 50;
        }
      }
      s1(tm);
      try { Thread.sleep(1000L);
      } catch (Exception e) {}
    }
  }
  
  public void concer() 
	{
		for (int m = 0; m < n - 1; m++) {
      int i1;
      if (srt[m][0] == 0)
      {
        for (i1 = srt[m][1]; i1 >= 0; i1--)
        {
          rougf(i1);
          x[i1] += 50;
        }
        
      }
      else {
        for (i1 = srt[m][2]; i1 <= n; i1++)
        {
          rougf(i1);
          x[i1] -= 50;
        }
      }
      update(m);
      s1(tm);
      try { Thread.sleep(1000L);
      }
      catch (Exception e) {}
    }
  }
  
  public void mergsort(int[]a, int i, int j) {
    if (i < j)
    {
      int m = (i + j) / 2;
      mrg[mc][0] = i;
      mrg[mc][1] = m;
      mrg[mc][2] = (m + 1);
      mrg[(mc++)][3] = j;
      
      mergsort(a, i, m);
      mergsort(a, m + 1,j);
      merg(a,i, m, m + 1, j);
    }
  }
  
  void merg(int[] a, int x1, int y1, int x2, int y2) {
  	 
    srt[sc][0] = x1;
    srt[sc][1] = y1;
    srt[sc][2] = x2;
    srt[(sc++)][3] = y2;
    
    int m = x1;
    int i1 = x2;
    int i2 = 0;
    while ((m <= y1) && (i1 <= y2))
    {
      if (ad == 1)
      {
        if (a[m] < a[i1]) {
          t[(i2++)] = a[(m++)];
        } else {
          t[(i2++)] = a[(i1++)];
        }
        
      }
      else if (a[m] > a[i1]) {
        t[(i2++)] = a[(m++)];
      } else {
        t[(i2++)] = a[(i1++)];
      }
    }
    while (m <= y1)
    {
      t[(i2++)] = a[(m++)];
    }
    while (i1 <= y2)
    {
      t[(i2++)] = a[(i1++)];
    }
   //System.out.println(" "+x1+" "+y1+" "+x2+" "+y2);
     for ( m=x1,i1 = 0; m <= y2; i1++,m++)
     	 {
           a[m] = t[i1];
           
           res[rs][i1] = t[i1];
           System.out.print(" "+res[rs][i1]);
    }
    System.out.println();
    rs += 1;    
  }
  
  public void s1(int[] a) {
    for (int m = 0; m < n; m++)
    {
      g.setColor(Color.red);
      g.fillRect(x[m], y[m], 99, 70);
      g.setColor(Color.BLACK);
      g.drawString("" + a[m], x[m] + 45, y[m] + 35);
    }
  }
  
  public void update(int i) {
    int m = srt[i][0]; for (int i1 = 0; m <= srt[i][3]; i1++)
    {
      tm[m] = res[i][i1];m++;
    }
  }
  
  public void rougf(int i) {
    g.setColor(Color.WHITE);
    g.fillRect(x[i], y[i], 99, 70);
  }
  
  public void copy(int[] a, int[] b) {
    for (int m = 0; m < n; m++) {
      a[m] = b[m];
    }
  }
  
  public static void main(String []args) {
    int[] a = { 5, 4, 3, 2, 1 };
    int[] b = { 1, 2, 3, 4, 5, 6 };
    o = new merg(b, 6, 2);
  }
}
