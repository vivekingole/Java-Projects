import java.util.*;
import java.awt.*;
import java.awt.event.*;
//import javafx.scene.layout.Border;
import javax.swing.*;
class sort extends JFrame implements ActionListener
{
    JLabel title;
    JButton b1,b2,b3;
    JPanel p1,p2,p3,p4;
    String no,elements;
    int n,item[]=new int[10];
    int ad;
    sort(String s)
    {
        super(s);
        title=new JLabel("Sorting Methods");
        title.setFont(new Font("Arial Rounded MT Bold",2,50));
        b1=new JButton("Bubble Sort");
        b2=new JButton("Insertion Sort");
        b3=new JButton("Merge Sort");
       
        setLayout(new GridLayout(4,1));
        setBounds(400,200,500,600);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        p1=new JPanel();
        p2=new JPanel();
        p3=new JPanel();
        p4=new JPanel();
        p1.add(title);
        p2.add(b1);
        p3.add(b2);
        p4.add(b3);         
        add(p1);
        add(p2);
        add(p3);
        add(p4);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        
    }
    public void actionPerformed(ActionEvent e)
    {
        int t,t1=0,i=0,c=0;
        Object o=e.getSource();
        ///////////////////////////
               no=JOptionPane.showInputDialog(this, "How many numbers ?");           
          for(;t1==0;)
          {    
           elements=JOptionPane.showInputDialog(this, "Enter elements :-");
           Scanner s=new Scanner(elements);
           try{
             for(i=0;((t=s.nextInt())!=-1);i++)
             {
               item[c++]=t;
             }
           }catch(Exception ex){}
           if((n=Integer.parseInt(no))==i)
               t1=1;
           else
                JOptionPane.showMessageDialog(this,"enter only "+no+" numbers","error",2);
          }//FOR        
          ad=JOptionPane.showConfirmDialog(this, "sort Ascending order?","Ascendng",JOptionPane.YES_NO_OPTION,3);
        ////////////////////////////
        if(o==b1)
        {
             if(ad==0)//ascending
             {
                   new bubble(item,n,1);
             }
             else  //descending
             {
                   new bubble(item,n,2);
             }
        }
        else if(o==b2)
        {
            if(ad==0)//ascending
             {
                   new insertion(item,n,1);
             }
             else  //descending
             {
                   new insertion(item,n,2);
             }
        }
        else if(o==b3)
        {
            if(ad==0)//ascending
             {
                   new merg(item,n,1);
             }
             else  //descending
             {
                   new merg(item,n,2);
             }
        }
    }
	
    public static void main(String ar[])
    {
        new sort("sorting methods");
    }
     
 
}