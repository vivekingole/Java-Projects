import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
 class insertion extends JFrame 
{
    static JFrame o;
  int x[]={200,300,400,500,600,700,800,900,1000,1100,0,0};
    int x1[]={200,300,400,500,600,700,800,900,1000,1100,0,0};
   int y[]={250,250,250,250,250,250,250,250,250,250,0,0};
   int n,item[]={0,0,0,0,0,0,0,0,0,0,0,0};
	 int resy=400;
    Graphics g;
    Container c;
		String res="";
    int t1,f=0,i,k,j,pass=1;
     insertion(int arr[],int n,int ad)
    {     
          setBounds(4,5,1300,800);
         setVisible(true);
         setLocation(150,50);
         setDefaultCloseOperation(1);         
        item=arr;
        this.n=n;        
        this.setLayout(null);
        c=this.getContentPane();
        c.setBackground(new Color(248,248,248));
		g=c.getGraphics();		       
		g.setColor(Color.red);
        g.setFont(new Font("Arial Rounded MT Bold",3,20));		
		pass=1;
		if(ad==1)//ascending
        {
             for(int i=1;i<n;i++)
                    {
						s1(x1);
		                for(int j=0;j<i;j++)
                            {
                                if(item[i]<item[j])
                               {
								   swap(j,i);
                                    t1=item[j];//									
                                    item[j]=item[i];//
                                    for( k=i;k>j;k--)//
                                    item[k]=item[k-1];//
                                    item[k+1]=t1;//									  									  									 
                                }
                            }
							if(i!=n)
							{
								res="";
								JOptionPane.showMessageDialog(this,"pass "+pass+" complete");
						        for(int k=0;k<n;k++)
									res=res+"  "+item[k];
								g.drawString("Pass  "+(pass++)+":  "+res,100,resy+=40);
							}
            }					
		}
        else//descending
        {
                for( i=1;i<n;i++)
                    {
						s1(x1);
                        for( j=0;j<i;j++)
                            {
                                if(item[i]>item[j])
                                {
									swap(j,i);
                                    t1=item[j];
                                    item[j]=item[i];
                                    for( k=i;k>j;k--)//
                                    item[k]=item[k-1];//
                                    item[k+1]=t1;    
                                }
                            }
							if(i!=n)
							{
								res="";
								JOptionPane.showMessageDialog(this,"pass "+pass+" complete");
						        for(int k=0;k<n;k++)
									res=res+"  "+item[k];
								g.drawString("Pass  "+(pass++)+":  "+res,100,resy+=40);
							}
           }
        }
				////////////////////// show result \\\\\\\\\\\\\\\\\\\\\/
				g.setColor(Color.red);
				g.setFont(new Font("Arial Rounded MT Bold",3,30));
        g.drawString("Sorted elements :- "+res,100,resy+=50);				
    }
	public void s1(int x[])
	{
		for(int i=0;i<n;i++)
        {   
			g.setColor(Color.red);
			g.fillRect(x[i],y[i],99,70);
			g.setColor(Color.BLACK);
			g.drawString(""+item[i],x[i]+45,y[i]+35);
		}
	}
	public void rougf(int i)
	{
		g.setColor(Color.WHITE);
		g.fillRect(x[i],y[i],99,70);
	}
	public void move(int i)
	{
		x[i]+=100;				
	}
	public void copy()
	{
		for(int i=0;i<n;i++)
			x[i]=x1[i];
	}
  public void swap(int l1,int l2)
  {
	  int f=0,m=i;
      int diff=x1[l2]-x1[l1];
      int total=diff+200;
      int t=0;	
       copy();//copy x1 into x	  
	  for(int i=1;i<=total+5;i+=5)
      {
		    g.setColor(Color.WHITE);
			g.fillRect(x[l2],y[l2],99,70);			
          if(i<=100)
          {
              y[l2]-=5;              
          }
          else if(i<=diff+100)
          {
             x[l2]-=5;     
          }
		  else
		  {
			  if(f==0)
			  {
				  f=1;				   
				  for(int k=l2-1;k>=l1;k--)
				  {		
					rougf(k);
					move(k);	
					s1(x);
					try{ Thread.sleep(200); }catch(Exception ex){}
		   		  }
				  
			  }
			  else 
			  y[l2]+=5;
		  }
		 s1(x);
		  try{ Thread.sleep(10); }catch(Exception ex){}   		 
      }
  }
   public static void main(String args[])
    {
        int a[]={5,4,3,2,1};
        int b[]={1,2,3,4,5,6};
         o=new insertion(b,6,2);
        
    }
 }
 