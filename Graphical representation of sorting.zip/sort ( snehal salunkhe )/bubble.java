import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
 class bubble extends JFrame 
{
   static JFrame o;
   int x[]={200,300,400,500,600,700,800,900,1000,1100,0,0};
   int y[]={250,250,250,250,250,250,250,250,250,250,0,0};
   int n,item[]={0,0,0,0,0,0,0,0,0,0,0,0};
   int resy=400;
   static Graphics g;
   static  Container c;
    int t1,f=0,pass=1;
	String res="";
     bubble(int arr[],int n,int ad)
    {      
         setBounds(4,5,1300,800);
         setVisible(true);
         setLocation(150,50);
         setDefaultCloseOperation(1);
        this.setLayout(null);        
        item=arr;
        this.n=n;        
        c=this.getContentPane();
        c.setBackground(new Color(248,248,248));
		g=c.getGraphics();		       
		g.setColor(Color.red);	
    g.setFont(new Font("Arial Rounded MT Bold",3,20));				
		pass=1;
        if(ad==1)//ascending
        {			
		     for(int i=0;i<=n-1;i++)
                    {						
		          				s1();        
                        for(int j=0;j<=n-2;j++)
                            {
                                if(item[j]>item[j+1])
                               {
								    
                                    t1=item[j];
                                    item[j]=item[j+1];
                                    item[j+1]=t1;									
                                    swap(j,j+1);										
									
								}
                            }
							if(i!=n-1)
							{
								res="";
								JOptionPane.showMessageDialog(this,"pass "+pass+" complete");
						        for(int k=0;k<n;k++)
									res=res+"  "+item[k];
								g.drawString("Pass  "+(pass++)+":  "+res,100,resy+=40);
							}	
						}                             
        }
        else//descending
        {
            for(int i=0;i<=n-1;i++)
                    {						
						s1();
                        for(int j=0;j<=n-2;j++)
                            {
                                if(item[j]<item[j+1])
                               {
								    
                                    t1=item[j];
                                    item[j]=item[j+1];
                                    item[j+1]=t1;
                                    swap(j,j+1);
                                }
                            }
							if(i!=n-1)
							{
								res="";
								JOptionPane.showMessageDialog(this,"pass "+pass+" complete");
						        for(int k=0;k<n;k++)
									res=res+"  "+item[k];
								g.drawString("Pass  "+(pass++)+":  "+res,100,resy+=40);
							}
            }
        }
				////////////////////// show result \\\\\\\\\\\\\\\\\\\\\/
				g.setColor(Color.red);
				g.setFont(new Font("Arial Rounded MT Bold",3,30));
        g.drawString("Sorted elements :- "+res,100,resy+=50);				
    }	
	public void s1()
	{
		for(int i=0;i<n;i++)
        {   
			g.setColor(Color.red);
			g.fillRect(x[i],y[i],99,70);
			g.setColor(Color.BLACK);
			g.drawString(""+item[i],x[i]+45,y[i]+35);
		}
	}
	
  public void swap(int l1,int l2)
  {
	   int diff=x[l2]-x[l1];
      int total=diff+200;
      int t=0;
      for(int i=1;i<=total;i+=5)
      {
		    g.setColor(Color.WHITE);
			g.fillRect(x[l1],y[l1],99,70);			
			g.fillRect(x[l2],y[l2],99,70);			
          if(i<=100)
          {
              y[l1]+=5;y[l2]-=5;              
          }
          else if(i<=diff+100)
          {
              x[l1]+=5;x[l2]-=5;            
          }
          else
          {
              y[l1]-=5;y[l2]+=5;        
          }
                        
		    g.setColor(Color.red);
			g.fillRect(x[l1],y[l1],99,70);
			g.fillRect(x[l2],y[l2],99,70);
			g.setColor(Color.BLACK);
			g.drawString(""+item[l2],x[l1]+45,y[l1]+35);
			g.drawString(""+item[l1],x[l2]+45,y[l2]+35);
            
		 try{
              Thread.sleep(10);
          }catch(Exception ex){}				
      }
	  int t1=x[l1];x[l1]=x[l2];x[l2]=t1;			  		  
	  s1();	  
  }
   public static void main(String args[])
    {
        int a[]={4,3,2,1};
        int b[]={1,2,3,4};
         o=new bubble(a,4,1);
        
    }
 }
 