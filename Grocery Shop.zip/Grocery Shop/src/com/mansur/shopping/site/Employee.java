package com.mansur.shopping.site;
class person{
	String name;
	int age;
	public person(String name, int age) {
		this.name = name;
		this.age = age;
	}
}
public class Employee extends person {
	int empid;
	String name;
	
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Employee(String name,int age,int empid, String company) {
		super(name,age);
		this.empid = empid;
		this.name = company;
		System.out.println(this.name);
		System.out.println(super.name);
		
	}

	public static void main(String args[]) {
		Employee e1=new Employee("Vivek",19,1001,"Capgemini");
	    
		System.out.println(e1.name);
	}
}
