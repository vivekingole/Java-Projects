package com.mansur.shopping.site;

import java.util.ArrayList;
import java.util.Scanner;

public class GroceryShop {

	ArrayList<Product> products= new ArrayList<>();
	ArrayList<Bill> bill= new ArrayList<>();
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args){
		int ch=0;
		GroceryShop gs=new GroceryShop();
		while(true) {
		System.out.println("Welcome to Grocery system");
		System.out.println("1. Add product");
		System.out.println("2. Delect Product");
		System.out.println("3. Search Product");
		System.out.println("4. Display Product List");
		System.out.println("5. In product");
		System.out.println("6. Out Product");
		System.out.println("7. List Out of stock Product");
		System.out.println("8. Update Product Rate");
		System.out.println("9. Create Bill");
		System.out.println("10. Print Bill");
		System.out.println("11. Exit");
		System.out.println("Please enter your choice : ");
		ch = sc.nextInt();
		sc.nextLine();
		switch(ch) {
		case 1:
			gs.addProduct();
			break;
		case 2:
			gs.deleteProduct();
			break;
		case 3:
			gs.searchProduct();
			break;
		case 4:
			gs.displayProductList();
			break;
		case 5:
			gs.inProduct();
			break;
		case 6:
			gs.outProduct();
			break;
		case 7:
			gs.stockList();
			break;
		case 8:
			gs.updatePrice();
			break;
		case 9:
			gs.createBill();
			break;
		case 10:
			gs.printBill();
			break;
		case 11:
			System.exit(0);
			break;
		default:
			System.out.println("Enter Valid choice !!!");
			break;
		}
	
		}
	}
	

	private void printBill() {
		for(Bill bl : bill)
		{
			System.out.println("----------***GROCERY SHOP***--------------");
			System.out.println("------------------------------------------");
			System.out.println("Bill No          : " + bl.getBillNo());
			System.out.println("Customer Name    : " + bl.getCustName());
			System.out.println("Product Name     : " + bl.getPName());
			System.out.println("Product Price    : " + bl.getPrice());
			System.out.println("Product Quantity : " + bl.getQTY());
			System.out.println("------------------------------------------");
		}
		
	}


	private void createBill() {
		System.out.println("-------------------GROCERY SHOP-----------------------");
		
		System.out.println("Enter Customer Name :");
		String custName=sc.nextLine();
		System.out.print("Enter Product name :");
		String pName =sc.nextLine();
		System.out.print("Enter Product QTY :");
		int QTY= sc.nextInt();
		System.out.print("Enter product Price :");
		float Price =sc.nextFloat();
		Bill bl=new Bill(custName, pName, QTY,  Price);
		bill.add(bl);
		bl.setBillNo(bl.getNewBillNumber());
		
	}


	private void updatePrice() {
		System.out.println("Enter Product Id :");
		int id=sc.nextInt();
		
		for(Product pr : products) 
		{
			if(pr.getpId()==id)
			{
				
				System.out.println("Product Price :" +pr.getPrice());
				System.out.println("Enter New Price :");
				float temp=sc.nextFloat();
				pr.setPrice(temp);
				System.out.println("Product price updated successfully");
				System.out.println("-----------------------------------");
				return;
			}
				
				
		}
		System.out.println("Sorry!!Product not found.");
		
		
	}

	private void stockList() {
		for(Product pr : products)
		{
			if(pr.getQty()==0)
			{
			System.out.println("ProductName : " + pr.getName());
			System.out.println("Product Quantity : " + pr.getQty());
			System.out.println("-----------------------------------");
			}
			}
		
	}

	private void inProduct() {
		
		System.out.println("Enter Product Id :");
		int id=sc.nextInt();
		
		for(Product pr : products) 
		{
			if(pr.getpId()==id)
			{
				
				System.out.println("Product Current QTY:" +pr.getQty());
				System.out.println("Enter New QTY :");
				int temp=sc.nextInt();
				temp+=pr.getQty();
				pr.setQty(temp);
				System.out.println("Product quantity updated successfully");
				System.out.println("-----------------------------------");
				return;
			}
				
				
		}
		System.out.println("Sorry!!Product not found.");
		
	}

	private void outProduct() {
		System.out.println("Enter Product Id :");
		int id=sc.nextInt();
		
		for(Product pr : products) 
		{
			if(pr.getpId()==id)
			{
				
				System.out.println("Product Current QTY:" +pr.getQty());
				System.out.println("Enter New QTY :");
				int temp=sc.nextInt();
				temp-=pr.getQty();
				pr.setQty(temp);
				System.out.println("Product quantity updated successfully");
				System.out.println("-----------------------------------");
				return;
			}
				
				
		}
		System.out.println("Sorry!!Product not found.");
		
		
	}

	

	private void displayProductList() {
		for(Product pr : products)
		{
			System.out.println("Product Id : " + pr.getpId());
			System.out.println("Product Name : " + pr.getName());
			System.out.println("Product Price : " + pr.getPrice());
			System.out.println("Product Quantity : " + pr.getQty());
			System.out.println("-----------------------------------");
		}
		
	}

	private void searchProduct() {
		System.out.println("Enter Product Id :");
		int id=sc.nextInt();
		for(Product pr : products) 
		{
			if(pr.getpId()==id)
			{
				System.out.println("Product Id :" +pr.getpId());
				System.out.println("Product Name :" +pr.getName());
				System.out.println("Product Price :" +pr.getPrice());
				System.out.println("Product Quantity :" +pr.getQty());
				System.out.println("-----------------------------------");
				
				return;
			}
				
				
		}
		System.out.println("Sorry!!Product not found.");
		
	}

	private void deleteProduct() {
		System.out.println("Enter Product Id :");
		int id=sc.nextInt();
		for(Product pr : products) {
				
		
			if(pr.getpId()==id)
			{
				products.remove(pr);
				System.out.println("Deleted");
				System.out.println("-----------------------------------");
				return;
			}
				
				
		}
		System.out.println("Sorry!!Product not found.");
	}

	private void addProduct() {
		System.out.print("Enter Product ID :");
		int pId= sc.nextInt();
		sc.nextLine();
		System.out.print("Enter Product name :");
		String name =sc.nextLine();
		System.out.print("Enter product Price :");
		float price =sc.nextFloat();
		System.out.print("Enter Product QTY :");
		int qty= sc.nextInt();
		Product pr=new Product(name,price,qty,pId);
		products.add(pr);
		System.out.println("Product Successfully Added");
		System.out.println("-----------------------------------");
	}

}
