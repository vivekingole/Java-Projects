package com.mansur.shopping.site;

public class Product {
	private String name;
	private float price;
	private int qty;
	private int pId;
	public Product(String name, float price, int qty, int pId) {
		super();
		this.name = name;
		this.price = price;
		this.qty = qty;
		this.pId=pId;
	}
	
	
	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
}
