package com.mansur.shopping.site;

public class Bill {
	static int billno=1;
	int BillNo,QTY;
	String CustName,PName;
	float Price;
	public Bill( String custName, String pName,int QTY, float Price) {
		
	
		this.QTY  = QTY;
		CustName = custName;
		PName = pName;
		this.Price = Price;
	}
	public int getBillNo() {
		return BillNo;
	}
	public void setBillNo(int billNo) {
		BillNo = billNo;
	}
	public int getQTY() {
		return QTY;
	}
	public void setQTY(int QTY) {
		this.QTY = QTY;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public String getPName() {
		return PName;
	}
	public void setPName(String pName) {
		PName = pName;
	}
	public float getPrice() {
		return Price;
	}
	public void setPrice(float price) {
		Price = price;
	}
	public int getNewBillNumber() {
		return ++billno;
	}
	
}
