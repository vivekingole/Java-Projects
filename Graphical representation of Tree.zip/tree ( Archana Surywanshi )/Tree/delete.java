import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;
import java.io.*;
public class delete extends JFrame implements MouseListener{
    
    JPanel p,p1[]=new JPanel[100],t1;
    JLabel title,name[]=new JLabel[100];
    Scanner s;
    int n,r=66,g=238,i,j,k,set[]=new int[100];
    String file;
    JButton open ,delete;
    FileInputStream fis;
    FileOutputStream fos;
    delete(String s1)
    {
        super(s1);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100,10,1400,830);
        t1=new JPanel();
        open=new JButton("Open");
        open.setBounds(100,700,100,50);
        delete=new JButton("Delete");
        delete.setBounds(1200,700,100,50);
        p=new JPanel();
        p.setBackground(new Color(251,144,225));
        p.setLayout(new GridLayout(10,1,5,5));
        p.setBounds(1,110,1400,550);
        title=new JLabel("Records");
        title.setFont(new Font("Arial Rounded BT Bold",3,50));
        title.setBounds(630,10,300,100);
        try
        {
            fis=new FileInputStream("tree.txt");
            s=new Scanner(fis);
            for(n=0;(file=s.next())!=null;n++)
            {
                p1[n]=new JPanel();
                p1[n].setBackground(new Color(r,g,255));               
                p1[n].addMouseListener(this); 
                p1[n].setLayout(new BorderLayout());
                name[n]=new JLabel(file,JLabel.CENTER);
                p1[n].add(name[n]);
                p.add(p1[n]);
            }
             }catch(Exception ex){}
         open.addMouseListener(this);
        delete.addMouseListener(this);
        add(open);
        add(delete);      
        add(title);
        add(p);
    }
  
    @Override
    public void mouseClicked(MouseEvent e){
     Object o=e.getSource();
     if(o==open)
     {
         tree.t1=file;
         try{
         fis=new FileInputStream(file+".txt");
         s=new Scanner(fis);
         for(int i=1;i<=40;i++)
         {
             tree.item[i]=s.nextInt();
         }
         }catch(Exception a){}
  
    tree.draw.draw1();       
    this.dispose();
         
     }
     else if(o==delete)
     {
         try {
             
              FileOutputStream fos=new FileOutputStream("tree.txt");
              DataOutputStream dos=new DataOutputStream(fos);
               for(int i=0;i<n;i++)
               {
                   if(name[i].getText()!=file)
                       dos.writeBytes(name[i].getText()+" ");
               }
              this.dispose();
              new File(file+".txt").delete();
              new delete("open");
         }catch(Exception es){}
     }     
    }
   public void mousePressed(MouseEvent e) {
       t1.setBackground(new Color(r,g,255));
       Object o=e.getSource();
      try{
          l1:for(int i=0;i<n;i++)
       {
           if(o==p1[i])
           {
               t1=p1[i];
               p1[i].setBackground(new Color(91,226,123));
               file=name[i].getText();
              break l1;
           }
       }
      }catch(Exception se){
      JOptionPane.showMessageDialog(this,"File not found");
       }
    }
    public void mouseReleased(MouseEvent e) { }    
    public void mouseEntered(MouseEvent e) { }
    public void mouseExited(MouseEvent e) { }
}
