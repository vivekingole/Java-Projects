import java.awt.event.*;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.util.*;
final class tree extends JFrame
{
    static JFrame o;
    static int x5=65;
    JMenuBar menubar;
    static JMenu file,create,insert,remove,search,count,display,exit;
    JMenuItem preorder,inorder,postorder,New,open,save,saveas,delete;
    JLabel lb,err;
    JButton bt,bt1;
    JTextField tf;
    JDialog d;
    JPanel p;
    static Container c;
    static Graphics g;
    static draw dr;
    int n=0,root=0,idx=0;
    String val;
    static int x[]=new int[]{0, 800, 400, 1200, 200, 600, 1000, 1400, 100, 300, 500, 700, 900, 1100, 1300, 1500, 30, 170, 230, 370, 430, 570, 630, 770, 830, 970, 1030, 1170, 1230, 1370, 1430, 1540};
    static int []y=new int[]{0,60,180,180,320,320,320,320,480,480,480,480,480,480,480,480,620,620,620,620,620,620,620,620,620,620,620,620,620,620,620,620};
    static int x1[]=new int[]{0,0,800,850,230,440,1030,1240,130,240,530,640,930,1040,1330,1440,60,140,260,340,460,540,660,740,860,940,1060,1140,1260,1340,1460,1540};
    static int x2[]=new int[]{0,0,430,1230,405,620,1210,1420,210,320,610,720,1010,1120,1410,1520,110,190,310,390,510,590,710,790,910,990,1110,1190,1310,1390,1510,1560};
    static int y1[]=new int[]{0,0,90,90,320,220,320,220,480,360,480,365,480,365,480,365,620,525,620,520,620,525,620,525,620,525,620,525,620,525,620,525};
    static int y2[]=new int[]{0,0,180,180,220,320,225,320,365,480,365,485,365,480,365,480,525,620,520,620,525,620,525,620,525,620,525,620,525,620,525,620};
    static int item[]=new int[x5];
    static int rootcreated=0,fi=0;
    int id=1;
    int sorted[]=new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
    static String t1;
	tree(String str)	{//constructor
		super(str);
        	this.setLayout(null);
		menubar =new JMenuBar();
		menubar.setBounds(0,0,1600,30);
		create=new JMenu("Create");
		insert=new JMenu("Insert");
		remove=new JMenu("Remove");
		search=new JMenu("Search");
		exit=new JMenu("Exit");
		count=new JMenu("Count");
                display=new JMenu("Display");
                inorder=new JMenuItem("Inorder");
		preorder=new JMenuItem("Preorder");
		postorder=new JMenuItem("Postorder");
                file=new JMenu("File");
                New=new JMenuItem("New");
                open=new JMenuItem("Open/Delete");
                save=new JMenuItem("Save");
                saveas=new JMenuItem("Save As");
                delete=new JMenuItem("Delete");
                
                   insert.addMouseListener(new inserte());
                   create.addMouseListener(new createe());
                   count.addMouseListener(new counte());
                   exit.addMouseListener(new createe());
                   search.addMouseListener(new searche());
                   preorder.addMouseListener(new displaye());
                   inorder.addMouseListener(new displaye());                   
                   postorder.addMouseListener(new displaye());
                   remove.addMouseListener(new removee());
                   New.addMouseListener(new filee());
                   open.addMouseListener(new filee());
                   save.addMouseListener(new filee());
                   saveas.addMouseListener(new filee());
                   delete.addMouseListener(new filee());                                                         
                menubar.add(file);
                file.add(New);
                file.add(open);
                file.add(save);
                file.add(saveas);
                menubar.add(create);
		display.add(preorder);
		display.add(inorder);
		display.add(postorder);
		menubar.add(insert);
		menubar.add(search);
		menubar.add(count);
		menubar.add(remove);
		menubar.add(display);
                menubar.add(exit);
                this.add(menubar);        
         }//Constuctor
     
        static class draw
        {
           draw()
           {}
           
          public static void draw1(){   
          create.setEnabled(false);
            rootcreated=1;
            c=o.getContentPane();
            g=c.getGraphics();
            g.setColor(Color.BLACK);
            g.drawString("Root", x[1]+10, y[1]-10);
            g.drawOval(x[1], y[1], 50, 50);
            g.drawString(""+item[1],x[1]+15, y[1]+30);
              
            for(int i=2;i<=32;i++)
            {
                if(item[i]!=0)
                {
                    g.drawLine(x1[i], y1[i], x2[i], y2[i]);
                    g.drawOval(x[i], y[i], 50, 50);
                    g.drawString(""+item[i], x[i]+15, y[i]+30);
                }
            }
           }
        }
        
        class filee implements MouseListener
        {                       
                   @Override
	public void mouseEntered(MouseEvent e){
		 		
	}
        @Override
	public void mouseExited(MouseEvent e){
                       
		}        
        @Override        
        public void mousePressed(MouseEvent e){}
        @Override
	public void mouseReleased(MouseEvent e){
            
             c=o.getContentPane();
             g=c.getGraphics();
             if(e.getSource()==New)
             {
               create.setEnabled(true);
               rootcreated=0;
               for(int i=1;i<=40;i++)
               {
                  item[i]=0;
               }
               g.setColor(new Color(238,238,238));
               g.fillRect(0, 31, 1595, 700);
               g.setColor(Color.BLACK);
             }//new
          
            
            if(e.getSource()==open)
            {
               //new 
                c=o.getContentPane();
                g=c.getGraphics();
                create.setEnabled(true);
                rootcreated=0;
                for(int i=1;i<=40;i++)
                {
                  item[i]=0;
                }
                g.setColor(new Color(238,238,238));
                g.fillRect(0, 31, 1595, 700);
                g.setColor(Color.BLACK);
                new delete("open");
            }    //open      
            else if(e.getSource()==save || e.getSource()==saveas)
            {
                if(item[40]==1 && e.getSource()==save)
                {
                    item[40]=1;
                  try{              
                   FileOutputStream fos=new FileOutputStream(t1+".txt");
                   DataOutputStream dos=new DataOutputStream(fos);
                   for(int i=1;i<=40;i++)
                   {
                     if(i==40)
                     {
                       dos.writeBytes("1 ");
                     }
                    else
                         dos.writeBytes(item[i]+" ");
                   }
                   JOptionPane.showMessageDialog(o,t1+" save");
                   }  //try
                   catch(Exception ae){} 
                }//if
                else if(item[40]!=1 || e.getSource()==saveas)
                {    
                    item[40]=1;
                  lb=new JLabel("Enter file name  :-");
                    lb.setSize(200,20);
                    lb.setLocation(40,40);
                    tf=new JTextField(20);
                    tf.setLocation(180,40);
                    tf.setSize(170,30);
                    bt=new JButton();
                    bt.setBounds(150,140,80,30);
                    bt.setBackground(new Color(204,255,255));
                    d=new JDialog(o);
                     d.setLayout(null);
                     d.setBounds(550,300,400,250);
                      d.setVisible(true);             
                    if(e.getSource()==save) 
                    {
                        d.setTitle("Save");                                    
                      bt.setText("Save");
                    }  
                    else
                    {   
                        d.setTitle("Save As");                   
                      bt.setText("Save As"); 
                    }  
                    bt.addMouseListener(new MouseAdapter()                            
                    {
                        public void mouseEntered(MouseEvent e)
                        {
                                  bt.setBackground(new Color(137,240,243));		
                      	}
                         @Override
	                   public void mouseExited(MouseEvent e){
                                bt.setBackground(new Color(204,255,255));
		           }        
                       public void mouseClicked(MouseEvent e)
                       {
                         t1=tf.getText();
                         try{
                         FileOutputStream fos=new FileOutputStream(tf.getText()+".txt");
                         DataOutputStream dos=new DataOutputStream(fos);
                         for(int i=1;i<=40;i++)
                         {                  
                           if(i==40)
                           {
                                dos.writeBytes("1 ");
                           }
                           else
                                 dos.writeBytes(item[i]+" ");
                        }
                  JOptionPane.showMessageDialog(o,tf.getText()+" saved");
                  dos.close();
                  fos.close();
                  fos=new FileOutputStream("tree.txt",true);
                  dos=new DataOutputStream(fos);
                  dos.writeBytes(tf.getText()+" ");
                  dos.close();
                  fos.close();                  
                  }//try
                  catch(Exception ae){}
                  d.setVisible(false);                           
                       }
                    });                    
                    d.add(lb);
                    d.add(bt);
                    d.add(tf);
                }//else if 
           }//save
           else if(e.getSource()==delete)
           {
               new delete("delete");
           }//delete
        }
        @Override
	public void mouseClicked(MouseEvent e){}
        }//////class file
        
        class createe implements MouseListener
        {        
            int set=1;
                   @Override
	public void mouseEntered(MouseEvent e){
		
	}
        @Override
	public void mouseExited(MouseEvent e){
                
		}        
        @Override        
        public void mousePressed(MouseEvent e){}
        @Override
	public void mouseReleased(MouseEvent e){
           }
        @Override
	public void mouseClicked(MouseEvent e){       
          if(e.getSource()==exit)
          {
            if(set==1)
            {
                set=0;
                c=o.getContentPane();
                g=c.getGraphics();
                lb=new JLabel("Are you sure ?");
                lb.setSize(200,20);
                lb.setLocation(40,40);
                bt=new JButton("Yes");
                bt.setBounds(85,140,80,30);
                bt.setBackground(new Color(204,255,255));
                JButton bt1=new JButton("No");
                bt1.setBounds(215,140,80,30);
                bt1.setBackground(new Color(204,255,255));
                d=new JDialog(o);
                d.setLayout(null);
                d.setBounds(550,300,400,250);
                d.setTitle("Exit");
                d.setVisible(true);
                d.add(lb);
                d.add(bt);
                d.add(bt1);
                bt.addMouseListener(new MouseAdapter()                            
                {
                    public void mouseEntered(MouseEvent e)
                    {
                        bt.setBackground(new Color(137,240,243));		
                    }
                    @Override
	            public void mouseExited(MouseEvent e){
                       bt.setBackground(new Color(204,255,255));
		    }        
                    public void mouseClicked(MouseEvent e)
                    {
                        System.exit(0); }
                });                    
                bt1.addMouseListener(new MouseAdapter()                            
                {
                    public void mouseEntered(MouseEvent e)
                    {
                        bt1.setBackground(new Color(137,240,243));		
                    }
                    @Override
	            public void mouseExited(MouseEvent e){
                         bt1.setBackground(new Color(204,255,255));
                    }        
                    public void mouseClicked(MouseEvent e)
                    {
                        d.dispose(); set=0; }
                });                    
            } //end of set if
          }
          else{      
                c=o.getContentPane();
                g=c.getGraphics();
                lb=new JLabel("Enter Value   :-");
                lb.setSize(200,20);
                lb.setLocation(40,40);
                tf=new JTextField(10);
                tf.setLocation(180,40);
                tf.setSize(100,30);
                bt=new JButton();
                bt.setBounds(150,140,80,30);
                bt.setBackground(new Color(204,255,255));
                d=new JDialog(o);
                d.setLayout(null);
                d.setBounds(550,300,400,250);
                if(rootcreated!=1)
                {    
                    g.drawString("Root", x[1]+10, y[1]-10);
                    g.drawOval(x[1], y[1], 50, 50);
                    rootcreated=1;
                    create.setEnabled(false);
                } 
	     }//mouse clicked
          }//else 
        }//class
           
        class inserte implements MouseListener
        {        
            int error=0,set=1;
        @Override
	public void mouseEntered(MouseEvent e){
            bt.setBackground(new Color(137,240,243));		
	}
        @Override
	public void mouseExited(MouseEvent e){
            bt.setBackground(new Color(204,255,255));
        }        
        @Override        
        public void mousePressed(MouseEvent e){
          if(item[31]!=0)
          {
              d.dispose();
               JOptionPane.showMessageDialog(d,"Please First Remove Node then Insert New Node\nBecause Tree Is Full");
               
          }
        }
        @Override
	public void mouseReleased(MouseEvent e){}
        @Override
	public void mouseClicked(MouseEvent e){  
            
            if(set==1)
            {     
                set=0;
                if( error==0)
                {
                    c=o.getContentPane();
                    g=c.getGraphics();
                    lb=new JLabel("Enter Value   :-");
                    lb.setSize(200,20);
                    lb.setLocation(40,40);
                    tf=new JTextField(10);
                    tf.setLocation(180,40);
                    tf.setSize(100,30);
                    bt=new JButton();
                    bt.setBounds(150,140,80,30);
                    bt.setBackground(new Color(204,255,255));
                    d=new JDialog(o);
                    d.setLayout(null);
                    d.setBounds(550,300,400,250);
                    d.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                    d.setTitle("Insert");
                    JOptionPane.showMessageDialog(o,"Enter Only Number");
                    d.setVisible(true);
                    bt.setText("Insert");
                    bt.addMouseListener(this);    
                    d.add(lb);
                    d.add(bt);
                    d.add(tf);
                    bt.addActionListener((ActionEvent el) -> {
                        val=tf.getText();
                        n=Integer.parseInt(val);
                        if(item[1]==0)
                        {                                   
                           item[1]=n;                       
                           g.drawString(val, x[1]+15, y[1]+30); 
                           d.dispose();                                  
                        }
                        else 
                        {
                         root=item[1];
                         idx=1;
                         loop: while(true)
                         {
                           if(n<root) 
                           {
                               idx*=2;
                               if(idx>31)
                               {   
                                  JOptionPane.showMessageDialog(o, "Space not available");
                                  JOptionPane.showMessageDialog(o, "Please enter another number");
                                  error=1;
                                  break loop;
                               }
                               else if(idx<=32 && item[idx]==0)
                               {
                                   item[idx]=n;
                                   g.drawOval(x[idx], y[idx], 50, 50);
                                   g.drawString(val, x[idx]+15, y[idx]+30);
                                   g.drawLine(x1[idx], y1[idx],x2[idx], y2[idx]);
                                   error=0; 
                                   d.dispose();
                                   break loop;
                               }
                               else root=item[idx];
                           }
                           else if(n>root)
                           {
                               idx=(idx*2)+1;
                               if(idx>31){ 
                                    JOptionPane.showMessageDialog(o, "Space not available");
                                     JOptionPane.showMessageDialog(o, "Please enter another number");
                                   error=1;
                                   break loop;
                               }
                               else if(idx<=32 && item[idx]==0)
                               {
                                   item[idx]=n;
                                   g.drawOval(x[idx], y[idx], 50, 50);
                                   g.drawString(val, x[idx]+15, y[idx]+30);
                                   g.drawLine(x1[idx], y1[idx],x2[idx], y2[idx]);
                                   error=0;
                                   d.dispose();
                                   break loop;
                               }
                               else root=item[idx];
                            }
                            else
                            { //if same no.
                               JOptionPane.showMessageDialog(o, "Do not repeat number");
                                JOptionPane.showMessageDialog(o, "Please enter another number");
                               error=1;
                               break loop;
                            }
                         }//while
                        }//if
                        set=1;
                    });
                }
            }   //end of set if
         } 
	}
        
        class counte implements MouseListener
        {        
             int set=1;
        @Override
	public void mouseEntered(MouseEvent e){
		 }
        @Override
	public void mouseExited(MouseEvent e){                       
		}        
        @Override        
        public void mousePressed(MouseEvent e){
            if(item[1]==0)
                {
                    JOptionPane.showMessageDialog(o, "Tree is Empty !");
                }
        }
        @Override
	public void mouseReleased(MouseEvent e){}
        @Override
	public void mouseClicked(MouseEvent e){
            if(set==1)
            {
                set=0;
                c=o.getContentPane();
                g=c.getGraphics();
                lb=new JLabel("Enter Value   :-");
                lb.setSize(200,20);
                lb.setLocation(40,40);
                tf=new JTextField(10);
                tf.setLocation(180,40);
                tf.setSize(100,30);
                bt=new JButton();
                bt.setBounds(150,140,80,30);
                bt.setBackground(new Color(204,255,255));
                d=new JDialog(o);
                d.setLayout(null);
                d.setBounds(550,300,400,250);
                d.setTitle("Insert");
                d.setVisible(true);
                bt.setText("Exit");
                bt.addMouseListener(new MouseAdapter()                            
                {
                    public void mouseEntered(MouseEvent e)
                    {
                        bt.setBackground(new Color(137,240,243));		
                    }
                    @Override
	            public void mouseExited(MouseEvent e){
                        bt.setBackground(new Color(204,255,255));
		    }        
                    public void mouseClicked(MouseEvent e)
                    {
                       
                        d.setVisible(false);
                        set=1;
                    }
                     
                });                    
                d.add(lb);
                d.add(bt);
                int c=0;
                for(int i=1;i<=31;i++)
                {
                    if(item[i]!=0)
                    c++;
                }
                lb.setText("   Total node is "+c);
                d.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }  //end of set if
           }
	}
         
        class searche implements MouseListener
        {        
            int i=0,set=1;
        @Override
	public void mouseEntered(MouseEvent e){
		bt.setBackground(new Color(137,240,243));		
	}
        @Override
	public void mouseExited(MouseEvent e){
                bt.setBackground(new Color(204,255,255));
        }       
        @Override        
        public void mousePressed(MouseEvent e){
            if(item[1]==0)
                {
                    JOptionPane.showMessageDialog(o, "Tree is Empty !");
                }
               
        }
        @Override
	public void mouseReleased(MouseEvent e){}
        @Override
	public void mouseClicked(MouseEvent e){
            if(set==1)
            {
                set=0;
                c=o.getContentPane();
                g=c.getGraphics();
                lb=new JLabel("Enter Value   :-");
                lb.setSize(200,20);
                lb.setLocation(40,40);
                tf=new JTextField(10);
                tf.setLocation(180,40);
                tf.setSize(100,30);
                bt=new JButton();
                bt.setBounds(150,140,80,30);
                bt.setBackground(new Color(204,255,255));
                d=new JDialog(o);
                d.setLayout(null);
                d.setBounds(550,300,400,250);
                d.setTitle("Search");
                d.setVisible(true);
                bt.setText("Search");
                bt.addMouseListener(this);                    
                d.add(lb);
                d.add(bt);
                d.add(tf);
                bt.addActionListener((ActionEvent el) -> {
                val=tf.getText();
                n=Integer.parseInt(val);
                idx=0;
                loop:  for( i=1;i<=32;i++)
                {
                    if(item[i]==n)
                    {
                        idx=1;
                        break;
                    }
                }
                d.dispose();
                JDialog d1=new JDialog(o);                                           
                d1.setLayout(null);
                d1.setBounds(550,300,400,250);
                d1.setTitle("Search");
                d1.setVisible(true);
                d1.add(lb);
                d1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                JButton bt1=new JButton("Exit");
                bt1.setBounds(150,140,80,30);
                bt1.setBackground(new Color(204,255,255));
                d1.add(bt1);
                if(idx==1)
                {
                    lb.setText("Node is found");
                }
                else
                {         
                    lb.setText("Node is not found");
                }
                bt1.addActionListener((ActionEvent elk) -> {
                  d1.dispose();
                  if(idx==1)
                  {                               
                    for(int j=1;j<=6;j++)
                    {
                      try{
                         Thread.sleep(100);
                      }catch(Exception es){}
                      if(j%2!=0)
                      {
                          g.setColor(new Color(0,224,242));
                          g.fillOval(x[i]+1, y[i]+1,49,49);
                          g.setColor(new Color(0,0,0));
                          g.drawString(""+item[i],x[i]+15,y[i]+30);
                      }
                      else
                      {
                          g.setColor(new Color(238,238,238));
                          g.fillOval(x[i]+1, y[i]+1,49,49);
                          g.setColor(new Color(0,0,0));
                          g.drawString(""+item[i],x[i]+15,y[i]+30);
                      }                                   
                    }                                
                   }
                });
                set=1;
               });
            }  //end of set if
          }
	}//Search
        
    class displaye implements MouseListener
    {      
        String str=new String();
        int cn=0,i=1,dl=550,ds=400,bl=150,dl1=550,ds1=400,bl1=150;
        @Override
	public void mouseEntered(MouseEvent e){ }
        @Override
	public void mouseExited(MouseEvent e){ }        
        @Override        
        public void mousePressed(MouseEvent e){  }
        @Override
	public void mouseReleased(MouseEvent e){ 
            id=1;
            d=new JDialog(o);
            cn=0;
            if(e.getSource()==preorder)                  
            {
                str="Preorder sequence is";
                preorderf(1);
                d.setTitle("preorder");                                     
            }
            else if(e.getSource()==inorder)
            {
                str="Inorder sequence is";
                inorderf(1);
                d.setTitle("inorder");
            }
            else if(e.getSource()==postorder)
            {
                str="Postorder sequence is";
                postorderf(1);
                d.setTitle("postorder");
            }          
            if(rootcreated==0 || item[1]==0)
                str="Tree is empty !";
            
                c=o.getContentPane();
                g=c.getGraphics();
                lb=new JLabel(str);
                lb.setSize(800,20);
                lb.setLocation(40,40);
                bt=new JButton("exit");
                bt.setBounds(bl,140,80,30);
                bt.setBackground(new Color(204,255,255));
                d.setLayout(null);
                d.setBounds(dl,300,ds,250);
                d.setVisible(true);
                d.add(lb);
                d.add(bt);
                d.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                bt.addMouseListener(new MouseAdapter()                            
                {
                    public void mouseEntered(MouseEvent e)
                    {
                        bt.setBackground(new Color(137,240,243));		
                    }
                    @Override
	            public void mouseExited(MouseEvent e){
                        bt.setBackground(new Color(204,255,255));
	            }        
                    public void mouseClicked(MouseEvent e)
                    {
                        d.setVisible(false);
                    }
                });   
                  
        } 
       
        public void preorderf(int idx)
        { 
            if(idx<=31)
            {    
                if(item[idx]!=0)      
                {
                    sorted[id++]=item[idx];
                    str=str+" "+sorted[id-1];
                    if(++cn>=6)
                    {
                        dl-=15;
                        ds+=30;
                        bl+=15;
                    }
                    else
                    {
                        dl=dl1;ds=ds1;bl=bl1;
                    }
               }
               preorderf(idx*2);
               preorderf((idx*2)+1);
            }
        }//preorder end
        
        public void inorderf(int idx)
        { 
            if(idx<=31)
            {   
                inorderf(idx*2);
                if(item[idx]!=0)      
                {
                    sorted[id++]=item[idx];
                    str=str+" "+sorted[id-1];
                    if(++cn>=6)
                    {
                        dl-=15;
                        ds+=30;
                        bl+=15;
                    }
                    else
                    {
                       dl=dl1;ds=ds1;bl=bl1;
                    }
                }
                inorderf((idx*2)+1);
            }
        }  //inorder end 
      
        public void postorderf(int idx)
        { 
            if(idx<=31)
            {     
                postorderf(idx*2);
                postorderf((idx*2)+1);
                if(item[idx]!=0)      
                {
                   sorted[id++]=item[idx];
                   str=str+" "+sorted[id-1];
                   if(++cn>=6)
                   {
                       dl-=15;
                       ds+=30;
                       bl+=15;
                   }
                   else
                   {
                       dl=dl1;ds=ds1;bl=bl1;
                   } 
                }
            } //if end
        } //postorder end
        @Override
	public void mouseClicked(MouseEvent e){  } 
    }  // end display class
             
class removee implements MouseListener
        {        
          int found=0,set=1;
                int swap=0,t1=0,t2=0,t3=0,t4=0,t6=0,t5=0,flag=0;
                JFrame d;
                 String msg;              
          class bte implements ActionListener
          { 
              
              public void actionPerformed(ActionEvent ae)
              {
                  set=1;
                  d.dispose();
                  if(item[1]==0)
                  {
                      d.setVisible(false);
                      d.dispose();
    
                  }    idx=1;
                          n=Integer.parseInt(tf.getText());
                          loop:for(int i=1;i<=31;i++)
                          {
                              if(item[i]==n)
                              {
                                  found=1;
                                  break  loop;
                              }
                          }
                          if(found==0)
                          {                            
                                  JDialog d1=new JDialog(o);                                           
                        d1.setLayout(null);
                        d1.setBounds(550,300,400,250);
                        d1.setTitle("Not found");
                        d1.setVisible(true);
                        lb.setText("Node not Found");
                        d1.add(lb);
                        d1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                        JButton bt1=new JButton("exit");
                        bt1.setBounds(150,140,80,30);
                        bt1.setBackground(new Color(204,255,255));
                        d1.add(bt1);                       
                        bt1.addActionListener((ActionEvent elk) -> {
                            d1.dispose();
                           
                        });
                                    
                          }
                         
                         else if(found==1)
                          {
                              idx=1;
                              loop2:while(true)
                              {
                                  root=item[idx];
                                  if(n<root)
                                  {
                                      idx=idx*2;
                                  }
                                  else if(n>root)
                                  {
                                      idx=(idx*2)+1;
                                  }
                                  else if(n==root)
                                  {
                                      break loop2;
                                  }
                              }//while
                                if((idx*2)>32 || (item[idx*2]==0 && item[(idx*2)+1]==0))  ///leaf node
                              {
                                    //to blink
                                  for(int j=1;j<=6;j++)
                                {
                                   try{
                                       Thread.sleep(100);
                                   }catch(Exception es){}
                                   if(j%2!=0)
                                   {
                                       g.setColor(new Color(255,65,81));
                                       g.fillOval(x[idx]+1, y[idx]+1,49,49);
                                       g.setColor(new Color(0,0,0));
                                       g.drawString(""+item[idx],x[idx]+15,y[idx]+30);
                                   }
                                   else
                                   {
                                      g.setColor(new Color(238,238,238));
                                       g.fillOval(x[idx]+1, y[idx]+1,49,49);
                                         g.setColor(new Color(0,0,0));
                                       g.drawString(""+item[idx],x[idx]+15,y[idx]+30);
                                      }                                   
                                }
                                    if(idx==1)
                                  {
                                      rootcreated=0;
                                      item[1]=0;
                                      create.setEnabled(true);
                                       g.setColor(new Color(238,238,238));                           
                                       g.drawString("Root", x[1]+10, y[1]-10);
                   
                                  }
                                  g.setColor(new Color(238,238,238));
                                  g.fillOval(x[idx]-2, y[idx]-2,60, 60);
                                  g.drawLine(x1[idx],y1[idx],x2[idx],y2[idx]);
                                  item[idx]=0;
                              }
                              else if((item[idx*2]!=0) && (item[(idx*2)+1]==0) ||  //only one node
                                      (item[idx*2]==0) && (item[(idx*2)+1]!=0))
                              {
                                  if(item[idx*2]!=0 && item[(idx*2)+1]==0)  //if node is left
                                  {
                                      swap=(idx*2);
                                      loop4: while(true)
                                    {
                                     if(item[(swap*2)+1]!=0)
                                     {
                                         swap=(swap*2)+1;
                                        
                                     }
                                     else if(item[(swap*2)]!=0 )
                                     {
                                        t1=item[idx];
                                        t6=t1;
                                        item[idx]=item[swap];
                                        item[swap]=t1;
                                            t4=idx;
                                             t5=swap;
                                        g.setColor(new Color(238,238,238));
                                        g.fillOval(x[idx]+2,y[idx]+2,46,46);                                     
                                        g.fillOval(x[swap]+2,y[swap]+2,46,46);
                                        g.setColor(Color.BLACK);
                                        //swaping
                                         for(int x1=x[idx],x2=x[swap],y1=y[idx],y2=y[swap],t2=x2,t3=y2;x1!=t2;)
                                        {
                                            g.setColor(new Color(238,238,238));
                                            g.drawString(Integer.toString(item[t5]),x1+15,y1+30);
                                            g.drawString(Integer.toString(item[t4]),x2+15,y2+30);                                            
                                                                     try{
                                       Thread.sleep(1);
                                   }catch(Exception es){}
                                           if(y1<=t3)
                                            {  y1++;y2--;}
                                            else{x1--;x2++;}
                                            
                                            g.setColor(Color.BLACK);         
                                            g.drawOval(x[idx],y[idx],50,50);
                                            g.drawOval(x[swap],y[swap],50,50);
                                            g.drawString(Integer.toString(item[t5]),x1+15,y1+30);
                                            g.drawString(Integer.toString(item[t4]),x2+15,y2+30);
                                                                  
                                        }   
                                       
                                        g.drawString(Integer.toString(item[idx]), x[idx]+15,y[idx]+30);  
                                        g.drawString(Integer.toString(item[swap]), x[swap]+15,y[swap]+30);
                                        idx=swap;                                        
                                        if(((swap*2))<=31)
                                          swap=(swap*2);
                                        
                                       }
                                    
                                    
                                    else
                                         break loop4;
                                    }
                                             t1=item[idx];
                                             t5=item[idx]=item[swap];
                                             item[swap]=0;
                                             //swapping
                                                    for(int x1=x[idx],x2=x[swap],y1=y[idx],y2=y[swap],t2=x2,t3=y2;x1!=t2;)
                                        {
                                            g.setColor(new Color(238,238,238));
                                            g.drawString(Integer.toString(t6),x1+15,y1+30);//t5
                                            g.drawString(Integer.toString(t5),x2+15,y2+30);//item[4]
                                                                     try{
                                       Thread.sleep(1);
                                   }catch(Exception es){}
                                              if(y1<=t3)
                                            {  y1++;y2--;}
                                            else{x1--;x2++;}
                                            
                                            g.setColor(Color.BLACK);     
                                             g.drawOval(x[idx],y[idx],50,50);
                                            g.drawOval(x[swap],y[swap],50,50);
                                            g.drawString(Integer.toString(t6),x1+15,y1+30);
                                            g.drawString(Integer.toString(t5),x2+15,y2+30);
                                                                  
                                        }   
                                                 //to blink
                                                       for(int j=1;j<=6;j++)
                                {
                                   try{
                                       Thread.sleep(100);
                                   }catch(Exception es){}
                                   if(j%2!=0)
                                   {
                                       g.setColor(new Color(255,65,81));
                                       g.fillOval(x[swap]+1, y[swap]+1,49,49);
                                       g.setColor(new Color(0,0,0));
                                       g.drawString(""+t1,x[swap]+15,y[swap]+30);
                                   }
                                   else
                                   {
                                      g.setColor(new Color(238,238,238));
                                       g.fillOval(x[swap]+1, y[swap]+1,49,49);
                                         g.setColor(new Color(0,0,0));
                                       g.drawString(""+t1,x[swap]+15,y[swap]+30);
                                      }                                   
                                }
                                             g.setColor(new Color(238,238,238));
                                            g.fillOval(x[idx]+2,y[idx]+2,46,46);      
                                            g.fillOval(x[swap]-5,y[swap]-5,60,60);      
                                           g.drawLine(x1[swap],y1[swap],x2[swap],y2[swap]);
                                            g.setColor(Color.BLACK);
                                            g.drawString(""+item[idx],x[idx]+15,y[idx]+30);
                                
                                  
                                  }                                     
                                  else    // if node is right
                                  {
                                      swap=(idx*2)+1;
                                      loop5: while(true)
                                    {
                                     if(item[(swap*2)]!=0)
                                     {
                                         swap=(swap*2);
                                        
                                     }
                                     else if(item[(swap*2)+1]!=0 )
                                     {
                                        t1=item[idx];
                                        item[idx]=item[swap];
                                        item[swap]=t1;
                                        t4=idx;
                                        t5=swap;
                                        g.setColor(new Color(238,238,238));
                                        g.fillOval(x[idx]+2,y[idx]+2,46,46);                                     
                                        g.fillOval(x[swap]+2,y[swap]+2,46,46);
                                        g.setColor(Color.BLACK);
                                        for(int x1=x[idx],x2=x[swap],y1=y[idx],y2=y[swap],t2=x2,t3=y2;x1!=t2;)
                                        {
                                            g.setColor(new Color(238,238,238));
                                            g.drawString(Integer.toString(item[t5]),x1+15,y1+30);
                                            g.drawString(Integer.toString(item[t4]),x2+15,y2+30);                                            
                                                                     try{
                                       Thread.sleep(1);
                                   }catch(Exception es){}
                                                                     if(y1<=t3)
                                            {  y1++;y2--;}
                                            else{x1++;x2--;}
                                            
                                            g.setColor(Color.BLACK);         
                                            g.drawOval(x[idx],y[idx],50,50);
                                            g.drawOval(x[swap],y[swap],50,50);
                                            g.drawString(Integer.toString(item[t5]),x1+15,y1+30);
                                            g.drawString(Integer.toString(item[t4]),x2+15,y2+30);
                                                                  
                                        }   
                                            idx=swap;                                        
                                        if(((swap*2)+1)<=31)
                                          swap=(swap*2)+1;
                                        
                                       }
                                     else
                                     {
                                         break loop5;
                                     }
                                         
                                      }
                                            t1=item[idx];
                                             t5=item[idx]=item[swap];
                                             
                                             item[swap]=0;
                                           
                                             for(int x1=x[idx],x2=x[swap],y1=y[idx],y2=y[swap],t2=x2,t3=y2;x1!=t2;)
                                        {
                                            g.setColor(new Color(238,238,238));
                                            g.drawString(Integer.toString(t5),x1+15,y1+30);
                                            g.drawString(Integer.toString(item[t4]),x2+15,y2+30);
                                                                     try{
                                       Thread.sleep(1);
                                   }catch(Exception es){}
                                                                     if(y1<=t3)
                                            {  y1++;y2--;}
                                            else{x1++;x2--;}
                                            
                                            g.setColor(Color.BLACK);     
                                             g.drawOval(x[idx],y[idx],50,50);
                                            g.drawOval(x[swap],y[swap],50,50);
                                            g.drawString(Integer.toString(t5),x1+15,y1+30);
                                            g.drawString(Integer.toString(item[t4]),x2+15,y2+30);
                                                                  
                                        }   
                                        // to blink
                                         for(int j=1;j<=6;j++)
                                {
                                   try{
                                       Thread.sleep(100);
                                   }catch(Exception es){}
                                   if(j%2!=0)
                                   {
                                       g.setColor(new Color(255,65,81));
                                       g.fillOval(x[swap]+1, y[swap]+1,49,49);
                                       g.setColor(new Color(0,0,0));
                                       g.drawString(""+t1,x[swap]+15,y[swap]+30);
                                   }
                                   else
                                   {
                                      g.setColor(new Color(238,238,238));
                                       g.fillOval(x[swap]+1, y[swap]+1,49,49);
                                         g.setColor(new Color(0,0,0));
                                       g.drawString(""+t1,x[swap]+15,y[swap]+30);
                                      }                                   
                                }
                                             g.setColor(new Color(238,238,238));
                                            g.fillOval(x[idx]+2,y[idx]+2,46,46);      
                                            g.fillOval(x[swap]-5,y[swap]-5,60,60);      
                                           g.drawLine(x1[swap],y1[swap],x2[swap],y2[swap]);
                                            g.setColor(Color.BLACK);
                                            g.drawString(""+item[idx],x[idx]+15,y[idx]+30);
                                  }
                                 
                                }
                              else     //if two child
                              {
                                     swap=(idx*2);
                                      loop4: while(true)
                                    {
                                     if(item[(swap*2)+1]!=0)
                                     {
                                         swap=(swap*2)+1;
                                        
                                     }
                                     else if(item[(swap*2)]!=0 )
                                     {
                                        t1=item[idx];
                                        t6=t1;
                                        item[idx]=item[swap];
                                        item[swap]=t1;
                                            t4=idx;
                                             t5=swap;
                                        g.setColor(new Color(238,238,238));
                                        g.fillOval(x[idx]+2,y[idx]+2,46,46);                                     
                                        g.fillOval(x[swap]+2,y[swap]+2,46,46);
                                        g.setColor(Color.BLACK);
                                        //swaping
                                         for(int x1=x[idx],x2=x[swap],y1=y[idx],y2=y[swap],t2=x2,t3=y2;x1!=t2;)
                                        {
                                            g.setColor(new Color(238,238,238));
                                            g.drawString(Integer.toString(item[t5]),x1+15,y1+30);
                                            g.drawString(Integer.toString(item[t4]),x2+15,y2+30);                                            
                                                                     try{
                                       Thread.sleep(1);
                                   }catch(Exception es){}
                                           if(y1<=t3)
                                            {  y1++;y2--;}
                                            else{x1--;x2++;}
                                            
                                            g.setColor(Color.BLACK);         
                                            g.drawOval(x[idx],y[idx],50,50);
                                            g.drawOval(x[swap],y[swap],50,50);
                                            g.drawString(Integer.toString(item[t5]),x1+15,y1+30);
                                            g.drawString(Integer.toString(item[t4]),x2+15,y2+30);
                                                                  
                                        }   
                                       
                                        g.drawString(Integer.toString(item[idx]), x[idx]+15,y[idx]+30);  
                                        g.drawString(Integer.toString(item[swap]), x[swap]+15,y[swap]+30);
                                        idx=swap;                                        
                                        if(((swap*2))<=31)
                                          swap=(swap*2);
                                        
                                       }
                                    
                                    
                                    else
                                         break loop4;
                                    }
                                             t1=item[idx];
                                             t5=item[idx]=item[swap];
                                             item[swap]=0;
                                             //swapping
                                                    for(int x1=x[idx],x2=x[swap],y1=y[idx],y2=y[swap],t2=x2,t3=y2;x1!=t2;)
                                        {
                                            g.setColor(new Color(238,238,238));
                                            g.drawString(Integer.toString(t6),x1+15,y1+30);//t5
                                            g.drawString(Integer.toString(t5),x2+15,y2+30);//item[4]
                                                                     try{
                                       Thread.sleep(1);
                                   }catch(Exception es){}
                                              if(y1<=t3)
                                            {  y1++;y2--;}
                                            else{x1--;x2++;}
                                            
                                            g.setColor(Color.BLACK);     
                                             g.drawOval(x[idx],y[idx],50,50);
                                            g.drawOval(x[swap],y[swap],50,50);
                                            g.drawString(Integer.toString(t6),x1+15,y1+30);
                                            g.drawString(Integer.toString(t5),x2+15,y2+30);
                                                                  
                                        }   
                                                 //to blink
                                                       for(int j=1;j<=6;j++)
                                {
                                   try{
                                       Thread.sleep(100);
                                   }catch(Exception es){}
                                   if(j%2!=0)
                                   {
                                       g.setColor(new Color(255,65,81));
                                       g.fillOval(x[swap]+1, y[swap]+1,49,49);
                                       g.setColor(new Color(0,0,0));
                                       g.drawString(""+t1,x[swap]+15,y[swap]+30);
                                   }
                                   else
                                   {
                                      g.setColor(new Color(238,238,238));
                                       g.fillOval(x[swap]+1, y[swap]+1,49,49);
                                         g.setColor(new Color(0,0,0));
                                       g.drawString(""+t1,x[swap]+15,y[swap]+30);
                                      }      
                                }
                                             g.setColor(new Color(240,240,240));
                                            g.fillOval(x[idx]+2,y[idx]+2,46,46);      
                                            g.fillOval(x[swap]-5,y[swap]-5,60,60);      
                                           g.drawLine(x1[swap],y1[swap],x2[swap],y2[swap]);
                                            g.setColor(Color.BLACK);
                                            g.drawString(""+item[idx],x[idx]+15,y[idx]+30);
                                
                                 
                               }
                          }
                         d.setVisible(false);
                         d.dispose();
                       g.setColor(Color.BLACK);
                        set=1;
              }//action
              
          }
          
                 @Override
	public void mouseEntered(MouseEvent e){
		
	}
        @Override
	public void mouseExited(MouseEvent e){
                
		}        
        @Override        
        public void mousePressed(MouseEvent e){}
        @Override
	public void mouseReleased(MouseEvent e){
           }
        @Override
	public void mouseClicked(MouseEvent e){
                      if(set==1)
                      {
                          set=0;
                      c=o.getContentPane();
                      g=c.getGraphics();
                      lb=new JLabel("Enter remove value   :-");
                    lb.setSize(200,20);
                    lb.setLocation(40,40);
                    tf=new JTextField(10);
                    tf.setLocation(180,40);
                    tf.setSize(100,30);
                    bt=new JButton("Remove");
                    bt.setBounds(150,140,80,30);
                    bt.setBackground(new Color(204,255,255));
                     d=new JFrame("Remove");
                     d.setLayout(null);
                     d.setTitle("Remove");
                     d.setBounds(550,300,400,250);
                     d.addWindowListener(new WindowAdapter(){
                     public void windowClosing(WindowEvent es)
                     {
                         set=1;
                         d.dispose();
                     }
                     });
                    d.setVisible(true);
                    d.add(lb);
                    d.add(tf);
                    d.add(bt);
                   if(item[1]==0)
                   {
                       d.remove(tf);
                       lb.setText("Tree is Empty !");
                       bt.setText("exit");
                   }
                  
                    bt.addActionListener(new bte());
              }   //end of set if
	}//mouse clicked
        }//class

        public static void main(String []args)throws NullPointerException
	{
	    o=new tree("Graphically representation of tree");
	    o.setVisible(true);
            o.setBounds(4,5,1600,850);      
            o.setResizable(false);	  
            o.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
}	
                         