import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import javax.swing.border.Border;
import javax.swing.plaf.BorderUIResource;
class time extends Thread
{
	Container c;
	JLabel t=new JLabel();
	time()
	{
		try{		
		c=test1.f.getContentPane();
		c.add(t);
		}catch(Exception ex){}
		t.setFont(new Font("Arial Rounded BT Bold",3,30));
		t.setBounds(1,1,200,50);
		t.setForeground(Color.GREEN);
		
	}
	public void run()
	{
		for(int i=test1.no*6;i>=0;i--)
		{
		  t.setText("Time 00:"+i);
		  if(i==30)
			  t.setForeground(Color.PINK);
		  else if(i==15)
			  t.setForeground(Color.red);
		  try{
			  Thread.sleep(1000);
		  }catch(Exception exs){}
		}
		JOptionPane.showMessageDialog(home.f,"Time Over !","time over",2);
	    test1.f.dispose();
	}
}

public class test1 extends JFrame implements MouseListener{
    static test1 f;
    JPanel p1=new JPanel();
    JPanel p2=new JPanel();
    JPanel p3=new JPanel();
    JPanel p4=new JPanel();
    JPanel p5=new JPanel();
    JPanel p51=new JPanel();
    
    JLabel title=new JLabel("Computerized Testing",JLabel.CENTER);
    JButton c=new JButton("     C    ");
    JButton cpp=new JButton("   C++   ");
    JButton java=new JButton("  JAVA    ");
    JButton dbms=new JButton("  DBMS    ");
    JButton appti=new JButton(" APPTI    ");
    JButton l[]=new JButton[41];
    JButton next=new JButton("next >>");
    JButton submit=new JButton("Submit");
    JLabel que=new JLabel("",JLabel.CENTER);
    JButton op[]=new JButton[5];
    JPanel sp1=new JPanel();
    JPanel sp2=new JPanel();
    JPanel sp3=new JPanel();
    JPanel sp4=new JPanel();
    JPanel sp5=new JPanel();
    JPanel sp=new JPanel();
    FileInputStream fis;
	FileOutputStream fos;
	DataOutputStream dos;
	Scanner s;
    int ans,res=0,ch,qi=0,rand[]=new int[41];
    String file1,name,s1;
    static int no=15;
    test1(String nm)
    {
		name=nm;
		System.out.print(name);
        setTitle("Computerised testing");
        setLayout(null);
        setDefaultCloseOperation(1);
        setVisible(true);
        setBounds(1,1,1130,850);       
        setLayout(null);
        //p1.setBounds(100,1,1600,100);            
        next.setBounds(200,600,150,50);
        next.setBackground(new Color(176,253,249));
        c.setFont(new Font("Arial Rounded BT Bold",3,30));
        cpp.setFont(new Font("Arial Rounded BT Bold",3,30));
        java.setFont(new Font("Arial Rounded BT Bold",3,30));
        dbms.setFont(new Font("Arial Rounded BT Bold",3,30));
        appti.setFont(new Font("Arial Rounded BT Bold",3,30));        
        //title.setFont(new Font("Arial Rounded BT Bold",2,40));
        que.setFont(new Font("Arial Rounded BT Bold",2,30));
        title.setSize(300,100);
        //p1.add(title);
        p2.setBounds(1, 100,1000,80);
        p2.setBackground(new Color(244,70,142));
    //    p3.setBackground(new Color(132,159,253));
        p4.setBackground(new Color(244,70,142));
        p2.add(c);
        p2.add(cpp);
        p2.add(java);
        p2.add(dbms);
        p2.add(appti);        
       // p3.add(que);
        for(int i=0;i<4;i++)
        {
            op[i]=new JButton("");
            op[i].setFont(new Font("Arial Rounded BT Bold",2,20));
            op[i].setBackground(new Color(176,253,249));
            op[i].addMouseListener(this);
        }
        p51.setBounds(1, 1,500, 300);
        p51.setLayout(new GridLayout(4,3,5,5));
         for(int i=0;i<no;i++)
        {
            l[i]=new JButton(""+(i+1));
            l[i].setFont(new Font("Arial Rounded BT Bold",2,20));
           l[i].addMouseListener(this);
           l[i].setBackground(new Color(176,253,249));
            p51.add(l[i]);
        }
        que.setBounds(1,220,1000,70);////
        p4.setBounds(50,320,500,200);
        p5.setBounds(600,300,600,500);//220
        p4.setLayout(new GridLayout(2, 2, 5, 5));
        p4.add(op[0]);
        p4.add(op[1]);
        p4.add(op[2]);
        p4.add(op[3]);
        
        p5.setLayout(null);
        submit.setBounds(190, 350, 100, 50);
        submit.setBackground(new Color(176,253,249));
        p5.add(submit);
        p5.add(p51);
        p5.setBackground(new Color(244,70,142));
        p51.setBackground(new Color(244,70,142));
        this.getContentPane().setBackground(new Color(244,70,142));
       // add(p1);//title
        add(p2);//sub
       // add(p3);//Que
        add(que);
        add(p4);//option
        add(p5);//labels
        add(next);
    
        c.addMouseListener(this);
        cpp.addMouseListener(this);
        java.addMouseListener(this);
        dbms.addMouseListener(this);
        appti.addMouseListener(this);
        submit.addMouseListener(this);
        next.addMouseListener(this);
    }
    public void st()
    {
    	
        time t1=new time();	
        t1.start();
       
    }
    public static void main(String []ac)
    {
       f=new test1("test");
       
    }
    public void start(String file)
    {
    	st();
        file1=file;
       random();
       qi=0;
        try{
        fis=new FileInputStream("d:\\"+file);
        }catch(Exception e2){System.exit(0);}
        Scanner s=new Scanner(fis);
       for(int i=1;i<rand[qi];i++)
       {
           s.nextLine();
           s.nextLine();
       }
        que.setText(s.nextLine());
        for(int i=0;i<=3;i++)
          op[i].setText(s.next());
        ans=s.nextInt();
        
        qi++;
       }
   public void mouseClicked(MouseEvent e) {
       Object o=e.getSource();
           if(o==c)           
		   {
         start("c.txt");           
			   s1="c";
		   }   
           else if(o==cpp)           
		   {
			   start("cpp.txt");   
			   s1="c++";
		   }
           else if(o==java)           
		   {
			   start("java.txt");   
			   s1="java";
		   }
           else if(o==dbms)           
		   {
		       start("dbms.txt");   
			   s1="dbms";
		   }
           else if(o==appti)           
		   {
			   start("appti.txt");   
			   s1="appti";
		   }
           else if(o==next)
           {           	 
               if(qi==no+1)  qi=0;
                   try{
                     fis=new FileInputStream("d:\\"+file1);
                   }catch(Exception e1){}
                    Scanner s=new Scanner(fis);
                  for(int i=1;i<rand[qi];i++)
                    {
                        s.nextLine();
                        s.nextLine();
                     }
                    que.setText(s.nextLine());
                    for(int i=0;i<=3;i++)
                    op[i].setText(s.next());
                    ans=s.nextInt();
                    l[qi-1].setBackground(Color.GREEN);
                    qi++;
                   
                 if(ans==ch)
                 {
                   res++;
                   ch=0;
                 }   
                
                   
            }           
           else if(o==submit)
           {
               JOptionPane.showMessageDialog(this,""+res);
			   try{
				   fos=new FileOutputStream("records.txt",true);
				   dos=new DataOutputStream(fos);
				   //dos.writeBytes("Name :- "+name+"  subject :- "+s1+" Marks :- "+no+" / "+res+"\n");
				   dos.writeBytes(name+"         "+s1+"         "+no+"/"+res+"\n");
				   dos.close();
				   fos.close();
			   }catch(Exception ex){}
			   this.dispose();
           }
    }
   public void random()
   {
       Random r=new Random();
       for(int j=0;j<no;j++)
       {
           rand[j]=(r.nextInt(40)+1);           
       }
   }
   public void mousePressed(MouseEvent e) {
       Object o=e.getSource();
       l:for(int i1=0;i1<no;i1++)
       {
           if(o==l[i1])
           {
             try{
                     fis=new FileInputStream("d:\\"+file1);
                   }catch(Exception e1){}
                    Scanner s=new Scanner(fis);
                    for(int i=1;i<rand[i1];i++)
                    {
                        s.nextLine();
                        s.nextLine();
                     }
                    que.setText(s.nextLine());
                    for(int i=0;i<=3;i++)
                    op[i].setText(s.next());
                    ans=s.nextInt();
                    qi++;
                   
                     if(ans==ch)
                 {
                   res++;
                   ch=0;
                 }
                     qi=i1+1;
              break l;
              
           }
       }
       
    }
   public void mouseReleased(MouseEvent e) {
       Object o=e.getSource();
       if(o==op[0])
       {
           if(ans==1)
               res++;
       }
       else if(o==op[1])
       {
            if(ans==2)
               res++;
       }
       else if(o==op[2])
       {
            if(ans==3)
               res++;
       }
       else if(o==op[3])
       {
            if(ans==4)
               res++;
       }
    }
   public void mouseEntered(MouseEvent e) {
    }
   public void mouseExited(MouseEvent e) {
    }
    
}
