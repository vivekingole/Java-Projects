import javax.swing.*;    
public class TableExample {    
    JFrame f;    
    TableExample(String data[][]){    
    f=new JFrame();    
    String column[]={"Name","Subject","Mark"};         
    JTable jt=new JTable(data,column);    
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f.add(sp);          
    f.setSize(1000,700);    
    f.setVisible(true);    
}     
public static void main(String[] args) {    
String data[][]={ {"101","Amit","670000"},    
                          {"102","Jai","780000"},    
                          {"101","Sachin","700000"}};    
    
    new TableExample(data);    
}    
}  