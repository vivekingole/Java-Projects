import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;
class home extends JFrame implements MouseListener
{
    static home f;
    JLabel title=new JLabel("Computerized Testing",JLabel.CENTER);	
    JLabel nm=new JLabel("Enter name :-");
    JTextField tf=new JTextField(15);
	JButton next=new JButton("next >>");
    JButton rec=new JButton("Records");
	JButton exit=new JButton("Exit");
	 FileInputStream fis;
	 Scanner s;
	 String data[][]=new String[100][4];
	home()
    {
		setVisible(true);
		  setLayout(null);     
        setBounds(1,1,600,600);		
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      title.setFont(new Font("Arial Rounded BT Bold",3,40));
      title.setBounds(50,50,500,50);	  
      nm.setBounds(100,200,200,50);
      nm.setFont(new Font("Arial Rounded BT Bold",3,20));
	tf.setBounds(250,200,250,50);
	tf.setFont(new Font("Arial Rounded BT Bold",3,30));
    exit.setBounds(50,400,100,50);	
	rec.setBounds(250,400,100,50);	
    next.setBounds(450,400,100,50);	
      add(title);
      add(nm);
      add(tf);	  
      add(exit);
	  add(rec);
	  add(next);
      exit.addMouseListener(this);
	  rec.addMouseListener(this);
	  next.addMouseListener(this);
    }
	public void mouseClicked(MouseEvent e) {
		Object o=e.getSource();
		if(o==exit)
		{
			System.exit(0);
		}
		else if(o==rec)
		{
			
			/*JFrame f1=new JFrame("records");
			f1.setVisible(true);
			f1.setBounds(100,100,700,700);
			f1.setDefaultCloseOperation(1);
			JTextArea ta=new JTextArea(100,100);
			ta.setEditable(false);
			ta.setFont(new Font("Arial Rounded BT Bold",3,20));
			ta.append("                                            	- : Records : -\n\n");
			ta.append("Name                      Sub                            Marks \n\n");
			f1.add(ta);
		*/	try{
				String t="abc";
				fis=new FileInputStream("records.txt");
				s=new Scanner(fis);
				try
				{				
				for(int i=0,j=0;(t=s.next())!=null;i++)
				{			
					data[i][0]=t;
					data[i][1]=s.next();
					data[i][2]=s.next();			
					}
				}catch(Exception e1){}
                new TableExample(data);
			}catch(Exception ex){ JOptionPane.showMessageDialog(null,ex);}
		}
		else if(o==next)
		{
			test1.no=Integer.parseInt(JOptionPane.showInputDialog(this,"enter no. of questions ","no. of question ",3));
			test1.f=new test1(tf.getText());
		}
	}
    public void mousePressed(MouseEvent e) {
    }
    public void mouseReleased(MouseEvent e) {
    }
    public void mouseEntered(MouseEvent e) {
    }
    public void mouseExited(MouseEvent e) {
    }
    public static void main(String []ac)
    {
       f=new home();
	   
    }
    
} 